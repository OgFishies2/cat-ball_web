print('this is cat ball')

name = input("what is your name")
print("hi "+name)
input()